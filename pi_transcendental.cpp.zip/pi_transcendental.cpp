// Transendental Search 

#include <iostream>
#include<vector>
#include <random>
#include <chrono>
#include <climits>
#include <thread>
#include <stdexcept> 
#include <fstream>
#include <string>

using namespace std;
using namespace chrono;


// Pi Digits file
string loadDigits(const string& filename) {
    ifstream file(filename);
    string digits, line;

    if (!file.is_open()) {
        cerr << "Failed to open file: " << filename << endl;
        return "";
    }

    while (getline(file, line)) {
        digits += line;  
    }

    file.close();
    return digits;
}


// KMP Algorithm

vector<int> computeLPSArray(string &pattern) {
    int n = pattern.size();
    vector<int> lps(n, 0);
        
    int len = 0;  
    int i = 1;

    while (i < n) {
        if (pattern[i] == pattern[len]) {
            len++;
            lps[i] = len;
            i++;
        } else {
            if (len != 0) { 
                len = lps[len - 1];  
            } else {
                lps[i] = 0;
                i++;
            }
        }
    }

    return lps;
}

// KMP Algorithm
vector<int> search(string &pat, string &txt) {
    int n = txt.length();
    int m = pat.length();

    // vector<int> lps(m);
    vector<int> res;
    vector<int> lps = computeLPSArray(pat);

    int i = 0;
    int j = 0;

    while (i < n) {
        if (txt[i] == pat[j]) {
            i++;
            j++;

            if (j == m) {
                int start = i - j;
                int end = i - 1;

                res.push_back(start);
                res.push_back(end);

                return {start, end};
            }
        }
        else {

            if (j != 0)
                j = lps[j - 1];
            else
                i++;
        }
    }
    return res;
}



int main() {
    
    string pi_path = "/Users/mudzingwa/Desktop/Spring 2026/pi_transendant/1b.txt";

    string txt = loadDigits(pi_path);
    if (txt.empty()) return 1;


    string pat;
    cout << "Enter number sequence to search for " << endl;
    cout << "In numerical format: ";
    cin >> pat;

    auto start_time = high_resolution_clock::now();
    vector<int> res = search(pat, txt);
    auto end_time = high_resolution_clock::now();

    if (res.empty()) {
        cout << "Pattern not found!" << endl;
    } else {
        cout << "Pattern found at position: ";
        // for (int idx : res) {
        //     cout << idx << " - ";
        // }
        // cout << endl;
        cout << res[0] << " - " << res[1] << endl;
    }

    auto duration = duration_cast<chrono::nanoseconds>(end_time - start_time);
    cout << duration.count() << " nanoseconds time taken to run algorithm" << endl;

    return 0;

}
